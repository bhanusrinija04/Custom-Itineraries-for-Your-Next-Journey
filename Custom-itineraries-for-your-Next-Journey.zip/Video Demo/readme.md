Video demonstration of project
