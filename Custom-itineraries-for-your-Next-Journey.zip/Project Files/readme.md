travel.py – Main file that runs the app and generates travel itineraries using AI.

requirements.txt – Contains required libraries to install and run the project.

API Key (Environment Variable) – Used to securely connect the app to the Gemini AI model.
